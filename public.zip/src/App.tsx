import { useEffect, useState } from "react";
import "./App.css";
import ModalComp from "./components/Modal";
import { getLocalStorageItem, setLocalStorageItem } from "./localStorageUtils";

export type DataType = {
  id: number;
  title: string;
};

function App() {
  const [data, setData] = useState<DataType[]>([]);
  const [value, setValue] = useState<string>("");
  const [lastItem, setLastItem] = useState<number>(0);
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const [editItem, setEditIem] = useState<DataType>({ id: 0, title: "" });

  // useEffect(() => {
  //   setLocalStorageItem("data", initialData);
  // }, []);

  useEffect(() => {
    const storedData = getLocalStorageItem<DataType[]>("data");
    setData(storedData || []); // Fallback to an empty array if storedData is null
  }, []);

  useEffect(() => {
    const ids = data?.map((item) => item.id);
    setLastItem(ids[ids.length - 1]);
  }, [data]);

  // console.log(lastItem);
  // console.log(data);
  const handleClick = () => {
    if (value) {
      setData([...data, { id: lastItem ? lastItem + 1 : 1, title: value }]);
      setLocalStorageItem("data", [
        ...data,
        { id: lastItem ? lastItem + 1 : 1, title: value },
      ]);
      setValue("");
    }
  };

  const handleDelete = (id: number) => {
    const filterData = data?.filter((item) => item.id !== id);
    setData(filterData);
    setLocalStorageItem("data", filterData);
  };

  const handleEdit = (id: number) => {
    const findItem = data?.find((item) => item.id === id);
    if (findItem) setEditIem(findItem);
    setIsOpen(true);
  };

  const handleClose = () => {
    setIsOpen(false);
  };

  const handleSubmit = (value: string) => {
    if (value) {
      const updatedItems = data.map((item) =>
        item.id === editItem.id ? { ...item, title: value } : item
      );
      setData(updatedItems);
      setLocalStorageItem("data", updatedItems);
      handleClose();
    }
  };

  return (
    <div>
      <ul>
        {data.map((item) => (
          <li key={item?.id}>
            {item?.title}{" "}
            <button type="submit" onClick={() => handleDelete(item?.id)}>
              Delete
            </button>
            <button type="submit" onClick={() => handleEdit(item?.id)}>
              edit
            </button>
          </li>
        ))}
      </ul>
      <input
        type="text"
        value={value}
        onChange={(e) => setValue(e.target.value)}
      />
      <button type="submit" onClick={handleClick}>
        add
      </button>
      {isOpen && (
        <ModalComp
          handleSubmit={handleSubmit}
          handleClose={handleClose}
          editItem={editItem}
        />
      )}
    </div>
  );
}

export default App;
