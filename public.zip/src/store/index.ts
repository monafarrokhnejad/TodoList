import { create } from "zustand";

type State = {
  count: number;
};

type Actions = {
  setZero: () => void;
  increase: () => void;
  setNum: (value: number) => void;
};

type Action = {
  type: keyof Actions;
  qty: number;
};

const countReducer = (state: State, action: Action) => {
  switch (action.type) {
    case "setZero":
      return { count: 0 };
    case "increase":
      return { count: state.count + 1 };
    case "setNum":
      return { count: state.count };
    default:
      return state;
  }
};

const useStore = create<State & Actions>((set) => ({
  count: 0,
  dispatch: (action: Action) => set((state) => countReducer(state, action)),
}));
