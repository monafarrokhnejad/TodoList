import { Reminder } from "../moldels/reminder";

interface ReminderListProps {
  items: Reminder[];
}

const ReminderList = ({ items }: ReminderListProps) => {
  return (
    <div>
      <ul className="">
        {items.map((item) => (
          <li className="" key={item.id}>
            {item.title}
          </li>
        ))}
      </ul>
    </div>
  );
};
export default ReminderList;
