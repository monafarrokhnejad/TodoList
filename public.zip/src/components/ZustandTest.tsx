function ZustandTest() {
  const { count, setZero, increase, setNum } = useStore();

  return (
    <>
      <div>{count}</div>
      <button onClick={() => setNum(10)} className="btn btn-success">
        Add
      </button>
      <button onClick={increase} className="btn btn success">
        increase
      </button>
      <button onClick={setZero} className="btn btn success">
        zero
      </button>
    </>
  );
}

export default ZustandTest;
