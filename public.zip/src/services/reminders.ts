import axios from "axios";
import { Reminder } from "../moldels/reminder";

class ReminderServices {
  http = axios.create({
    baseURL: "https://jsonplaceholder.typicode.com",
  });
  async getReminders() {
    const response = await this.http.get<Reminder[]>("/todos");
    return response.data;
  }
}
const reminderService = new ReminderServices();
export default reminderService;
