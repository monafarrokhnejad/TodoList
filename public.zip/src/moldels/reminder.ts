export interface Reminder {
  id: number;
  title: string;
  userId: number;
  completed: boolean;
}
